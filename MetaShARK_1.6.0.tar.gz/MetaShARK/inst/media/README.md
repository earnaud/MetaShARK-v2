# MetaShARK / Media

This folder contains multimedia files for multiple purposes. These must be either useful for the app, for the dev or any user-service purpose.

## EAL diagram

EAL_diagram was drawn using [Diagram Editor](https://www.diagrameditor.com/), a free service allowing the user to draw some diagrams with a wide variety of shapes (no ad, it is just a quick description of the tool and why the dev decided to work with it).
