library(MetaShARK)

runMetashark(use.test=TRUE)