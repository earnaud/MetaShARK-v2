#' Executed after changing page
#'
#' @import shiny
#' @importFrom jsonlite write_json serializeJSON
#'
#' @noRd
saveReactive <- function(main_env, page, do.template = TRUE) {
  if (is.null(main_env$local_rv)) {
    stop("No content provided.")
  }
  if (is.null(main_env$save_variable)) {
    stop("No save_variable provided")
  }

  withProgress({
    isolate({
      # Save local variable content ----
      setProgress(1 / 3, "Save metadata")
      .tmp.save <- NULL
      if (page != 9) {
        .tmp.save <- do.call(
          what = switch(page,
            ".saveSelectDP",
            ".saveDataFiles",
            ".saveAttributes",
            ".saveCatVars",
            ".saveGeoCov",
            ".saveTaxCov",
            ".savePersonnel",
            ".saveMisc"
          ),
          args = list(main_env)
        )

        if (class(.tmp.save) != "try-error" || !is.null(.tmp.save)) {
          main_env$save_variable <- .tmp.save
        }
      }

      # Template ----
      .tmp.template <- TRUE
      if (isTRUE(do.template)) {
        .tmp.template <- templateModules(main_env, page)
      }

      # Error catching ----
      # If an error came out, do not go further
      if (class(.tmp.save) == "try-error" || class(.tmp.template) == "try-error") {
        browser() # not page-1 but page <- oldpage: comes back to previously visited
        isolate({
          main_env$EAL$page <- main_env$EAL$old_page
        })
        setProgress(1, "Exit save")
        stop("Error arose while saving.")
      }

      # Save JSON ----
      setProgress(2 / 3, "Write JSON")

      # set files + path
      path <- main_env$save_variable$SelectDP$dp.path
      filename <- main_env$save_variable$SelectDP$dp.name
      location <- paste0(path, "/", filename, ".json")

      # overwrite files
      if (dir.exists(path)) {
        if (file.exists(location)) {
          file.remove(location)
        }
        jsonlite::write_json(
          jsonlite::serializeJSON(
            listReactiveValues(main_env$save_variable)
          ),
          location
        )
      } else {
        devmsg("%s not found.", path, tag = "fill_module_saves.R")
      }

      setProgress(1)
    }) # end of isolate
  })

  showNotification(
    paste("Saved:", main_env$EAL$current, "."),
    duration = 2.5,
    type = "message"
  )

  return(NULL)
}

#' @noRd
.saveSelectDP <- function(main_env) {
  # Shortcuts
  .sv <- main_env$save_variable
  content <- main_env$local_rv
  # browser()
  # Save content in sv
  .sv$SelectDP$dp.name <- content$dp.name()
  .sv$SelectDP$dp.path <- paste0(
    main_env$PATHS$eal_dp,
    content$dp.name(),
    "_emldp"
  )
  .sv$SelectDP$dp_metadata_path <- paste(
    .sv$SelectDP$dp.path,
    content$dp.name(),
    "metadata_templates",
    sep = "/"
  )
  .sv$SelectDP$dp.data.path <- paste(
    .sv$SelectDP$dp.path,
    content$dp.name(),
    "data_objects",
    sep = "/"
  )
  .sv$SelectDP$dp_eml_path <- paste(
    .sv$SelectDP$dp.path,
    content$dp.name(),
    "eml",
    sep = "/"
  )
  .sv$SelectDP$dp.title <- content$dp.title()
  # .sv$quick <- content$quick
  .sv$creator <- if (isTRUE(main_env$SETTINGS$logged)) {
    main_env$SETTINGS$user
  } else {
    "public"
  } # prefered to set it properly than only with variable

  return(.sv)
}

#' @importFrom dplyr select
#'
#' @noRd
.saveDataFiles <- function(main_env) {
  .sv <- main_env$save_variable
  .tmp <- main_env$local_rv$data.files
  .tmp <- try(dplyr::select(.tmp, -id), silent = TRUE)
  # Format content
  if (!isContentTruthy(.tmp) || class(.tmp) == "try-error") {
    devmsg("Invalid content.", tag = "fill_module_saves.R")
    # don't change .sv
  } else {
    # -- Get files data
    .from <- .tmp$datapath
    .to <- paste0(
      .sv$SelectDP$dp.data.path,
      "/", .tmp$name
    )
    file.copy(
      from = .from,
      to = .to
    )
    .tmp$datapath <- .to

    # -- set metadatapath
    .tmp$metadatapath <- paste(
      .sv$SelectDP$dp_metadata_path,
      sub(
        "(.*)\\.[a-zA-Z0-9]*$",
        "attributes_\\1.txt",
        .tmp$name
      ),
      sep = "/"
    )
    .tmp[] <- lapply(.tmp, as.character)

    # Save
    .sv$DataFiles <- .tmp
    try(main_env$local_rv$data.files$datapath <- .tmp$datapath)
  }

  return(.sv)
}

#' @importFrom dplyr filter select
#' @importFrom data.table fwrite
#'
#' @noRd
.saveAttributes <- function(main_env) {
  .sv <- main_env$save_variable
  content <- main_env$local_rv
  # Save
  .sv$Attributes$content <- content$md.tables
  devmsg(names(content$md.tables), tag = "save attributes")

  # Write attribute tables
  sapply(
    names(content$md.tables),
    function(tablename) {
      # write filled tables
      path <- .sv$DataFiles |>
        dplyr::filter(grepl(tablename, metadatapath)) |>
        dplyr::select(metadatapath) |>
        unlist()
      table <- content$md.tables[[tablename]]
      data.table::fwrite(table, path, sep = "\t")
    }
  )

  # Write Custom units
  if (isContentTruthy(content$CU_Table)) {
    data.table::fwrite(
      content$CU_Table,
      paste0(.sv$SelectDP$dp_metadata_path, "/custom_units.txt")
    )
  }

  # Add use of categorical variables (or not)
  # .sv$Attributes$use_catvars <- isTRUE(content$use_catvars())

  return(.sv)
}

#' @importFrom data.table fwrite
#'
#' @noRd
.saveCatVars <- function(main_env) {
  content <- main_env$local_rv

  sapply(content$cv.files, function(file.path) {
    devmsg(file.path)
    file.name <- basename(file.path)

    # Save
    main_env$save_variable$CatVars[[file.name]] <- content$cv.tables[[file.name]]

    # Overwrite
    file.remove(file.path)
    data.table::fwrite(
      main_env$save_variable$CatVars[[file.name]],
      file.path,
      sep = "\t",
      na = "NA",
      quote = FALSE
    )
  })

  return(main_env$save_variable)
}

#' @noRd
#'
#' @importFrom data.table fwrite
#' @importFrom sf st_polygon st_as_text
#' @importFrom dplyr bind_rows
#' @import shiny
.saveGeoCov <- function(main_env) {
  .sv <- main_env$save_variable
  # browser()
  # Initialize variables
  .method <- main_env$local_rv$method

  data.files <- .sv$DataFiles$datapath
  data.content <- lapply(data.files, readDataTable)
  names(data.content) <- basename(data.files)

  # format extracted content - keep latlon-valid columns
  data.content.coordinates <- lapply(
    names(data.content),
    function(data.filename) {
      df <- data.content[[data.filename]]
      df.num <- unlist(
        lapply(df, function(df.col) {
          df.col <- df.col[!is.na(df.col)]
          if (is.character(df.col)) {
            df.col <- enc2utf8(df.col)
          }
          all(grepl(main_env$PATTERNS$coordinates, df.col))
        })
      )
      df[, df.num]
    }
  )
  names(data.content.coordinates) <- basename(data.files)

  .values <- list(
    data.content = data.content,
    data.content.coordinates = data.content.coordinates
  )

  geocov <- NULL
  .sv$GeoCov <- reactiveValues() # reset
  .sv$GeoCov$method <- .method

  # Columns ----
  if (.method == "columns" &&
    isContentTruthy(main_env$local_rv$columns$site) &&
    isContentTruthy(main_env$local_rv$columns)) {
    devmsg("Geographic Coverage saved with columns", tag = "fill_module_saves.R")
    .sv$GeoCov$columns <- main_env$local_rv$columns

    # Site
    # site <- listReactiveValues(main_env$local_rv$columns$site)
    # .geographicDescription <- .values$data.content[[site$file]][[site$col]]
    #
    # # extract queried
    # .tmp <- extractCoordinates(
    #   main_env,
    #   "lat",
    #   main_env$PATTERNS$coordinates,
    #   .values$data.content
    # )
    # .northBoundingCoordinate <- .tmp$coordinates$N
    # .southBoundingCoordinate <- .tmp$coordinates$S
    # .lat.index <- .tmp$coord.index
    #
    # .tmp <- extractCoordinates(
    #   main_env,
    #   "lon",
    #   main_env$PATTERNS$coordinates,
    #   .values$data.content
    # )
    # .eastBoundingCoordinate <- .tmp$coordinates$E
    # .westBoundingCoordinate <- .tmp$coordinates$W
    # .lon.index <- .tmp$coord.index
    #
    # # Get only lines fully completed
    # .index <- intersect(.lat.index, .lon.index)
    # # .northBoundingCoordinate <- .northBoundingCoordinate[.lat.index[.lat.index %in% .index]]
    # # .southBoundingCoordinate <- .southBoundingCoordinate[.lat.index[.lat.index %in% .index]]
    # # .eastBoundingCoordinate <- .eastBoundingCoordinate[.lon.index[.lon.index %in% .index]]
    # # .westBoundingCoordinate <- .westBoundingCoordinate[.lon.index[.lon.index %in% .index]]
    # .geographicDescription <- .geographicDescription[.index]
    #
    # # Final
    # geocov <- data.frame(
    #   geographicDescription = .geographicDescription,
    #   northBoundingCoordinate = .northBoundingCoordinate,
    #   southBoundingCoordinate = .southBoundingCoordinate,
    #   eastBoundingCoordinate = .eastBoundingCoordinate,
    #   westBoundingCoordinate = .westBoundingCoordinate,
    #   stringsAsFactors = FALSE
    # )

    # Templated
    geocov <- NULL
  }

  # Custom ----
  if (.method == "custom") {
    devmsg("Geographic Coverage saved with custom", tag = "fill_module_saves.R")
    # shortcuts
    .local_rv <- main_env$local_rv$custom
    .features.ids <- names(.local_rv)[
      !names(.local_rv) %in% c("count", "complete")
    ]

    # build coverage table from local_rv
    .custom.coordinates <- lapply(.features.ids, function(feat.id) {
      .points <- .local_rv[[feat.id]]$points
      if (.local_rv[[feat.id]]$type == "marker") {
        .points <- .points[1, ]
      }
      if (.local_rv[[feat.id]]$type == "rectangle") {
        .points <- .points[1:2, ]
      }

      data.frame(
        geographicDescription = .local_rv[[feat.id]]$description,
        northBoundingCoordinate = max(.points$lat),
        southBoundingCoordinate = min(.points$lat),
        eastBoundingCoordinate = max(.points$lon),
        westBoundingCoordinate = min(.points$lon),
        wkt = if (.local_rv[[feat.id]]$type == "polygon") {
          .points[c(1:nrow(.points), 1), 2:3] |>
            as.matrix() |>
            list() |>
            st_polygon() |>
            st_as_text()
        } else {
          ""
        }
      ) # end of data.frame
    }) |>
      bind_rows()

    # save
    .sv$GeoCov$custom <- main_env$local_rv$custom

    # fill
    geocov <- .custom.coordinates
  }

  # Write data
  if (isContentTruthy(geocov)) {
    data.table::fwrite(
      geocov[, 1:5], # do not write wkt column in geocov
      paste(
        .sv$SelectDP$dp_metadata_path,
        "geographic_coverage.txt",
        sep = "/"
      ),
      sep = "\t"
    )

    if ("wkt" %in% names(geocov)) {
      data.table::fwrite(
        geocov["wkt"], # do not write wkt column in geocov
        paste(
          .sv$SelectDP$dp_metadata_path,
          ".spatial_coverage.txt",
          sep = "/"
        ),
        sep = "\t"
      )
    }
  }

  # Output
  return(.sv)
}

#' @noRd
.saveTaxCov <- function(main_env) {
  .sv <- main_env$save_variable
  content <- main_env$local_rv

  # Save
  .sv$TaxCov$taxa_table <- content$taxa_table
  .sv$TaxCov$taxa.col <- content$taxa.col
  .sv$TaxCov$taxa.name.type <- content$taxa.name.type
  .sv$TaxCov$taxa.authority <- content$taxa.authority

  main_env$save_variable <- .sv
}

#' @importFrom data.table fwrite
#' @importFrom dplyr mutate
#'
#' @noRd
.savePersonnel <- function(main_env) {
  .sv <- main_env$save_variable
  content <- main_env$local_rv

  if (isContentTruthy(content$Personnel)) {
    # Save variable
    .sv$Personnel <- content$Personnel

    # Write file
    # prettify
    cols <- c(
      "givenName", "middleInitial", "surName",
      "organizationName", "electronicMailAddress",
      "userId", "role",
      "projectTitle", "fundingAgency", "fundingNumber"
    )
    personnel <- content$Personnel[names(content$Personnel) %in% cols]
    .personnel <- personnel[NULL, ]
    sapply(seq_row(personnel), function(ind) {
      row <- personnel[ind, ]

      roles <- unlist(strsplit(row$role, ","))
      lapply(seq(roles), function(ind) {
        .personnel <<- rbind(
          .personnel,
          row |> dplyr::mutate(role = roles[ind])
        )
      })
    })

    # File template for personnel
    data.table::fwrite(
      .personnel,
      paste0(
        .sv$SelectDP$dp_metadata_path,
        "/personnel.txt"
      ),
      sep = "\t"
    )
  }

  # Output
  return(.sv)
}

#' @import shiny
#' @importFrom data.table fwrite
#' @importFrom htmltools save_html HTML
#' @importFrom rmarkdown pandoc_convert
#' @importFrom dplyr bind_rows
#'
#' @noRd
.saveMisc <- function(main_env) {
  .sv <- main_env$save_variable
  content <- main_env$local_rv

  saveHTMLasMD <- function(.content) {
    .tmp.file <- tempfile(fileext = ".html")
    htmltools::save_html(html = htmltools::HTML(.content$content), .tmp.file)
    rmarkdown::pandoc_convert(
      .tmp.file,
      from = "html",
      to = "markdown_strict",
      output = .content$file
    )
  }

  removeDuplicateFiles <- function(filename) {
    if (isContentTruthy(filename)) {
      onlyname <- sub("\\..+", "", basename(filename))
      synonyms <- dir(
        main_env$save_variable$SelectDP$dp_metadata_path,
        pattern = onlyname,
        full.names = TRUE
      )
      file.remove(synonyms[basename(synonyms) != basename(filename)])
    }
  }

  # save local variable ----
  content$abstract$file <- paste0(.sv$SelectDP$dp_metadata_path, "/abstract.md")
  content$methods$file <- paste0(.sv$SelectDP$dp_metadata_path, "/methods.md")
  content$additional_information$file <- paste0(
    .sv$SelectDP$dp_metadata_path,
    "/additional_info.md"
  )
  .sv$Misc <- content

  # abstract ----
  saveHTMLasMD(content$abstract)
  removeDuplicateFiles(content$abstract$file)

  # methods ----
  saveHTMLasMD(content$methods)
  removeDuplicateFiles(content$methods$file)

  # keywords ----
  # Set NA thesaurus as "" thesaurus
  content$keywords$keywordThesaurus <- replace(
    content$keywords$keywordThesaurus,
    which(is.na(content$keywords$keywordThesaurus)),
    ""
  )

  # build keywords data.frame
  .keywords <- lapply(unique(content$keywords$keywordThesaurus), function(kwt) {
    row.ind <- which(content$keywords$keywordThesaurus == kwt)

    data.frame(
      keyword = strsplit(content$keywords$keyword[row.ind], ",") |>
        unlist(),
      keywordThesaurus = kwt # repeated as many times as necessary
    )
  }) |>
    dplyr::bind_rows()

  # write files
  data.table::fwrite(
    .keywords,
    paste0(
      .sv$SelectDP$dp_metadata_path,
      "/keywords.txt"
    ),
    sep = "\t"
  )

  # additional information ----
  saveHTMLasMD(content$additional_information)
  removeDuplicateFiles(content$additional_information$file)

  # Remove non-md files
  # sapply(c("abstract", "methods", "additional_information"), function(x) {
  #   file.remove(
  #     dir(
  #       main_env$save_variable$SelectDP$dp_metadata_path,
  #       full.names = TRUE,
  #       pattern = paste0("^.*", x, ".*\\.[^md]$")
  #     )
  #   )
  # })

  # Output
  return(.sv)
}
