MetaFINUI <- function(id, main.env) {
  ns <- NS(id)
  tagList(
    tags$h1("Nothing yet ...")
  )
}

MetaFIN <- function(id, main.env) {
moduleServer(id, function(input, output, session) {
    
  })
}