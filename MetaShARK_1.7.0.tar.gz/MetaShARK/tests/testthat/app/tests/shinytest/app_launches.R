app <- ShinyDriver$new("../../")
app$snapshotInit("app_launches")

app$snapshot()
