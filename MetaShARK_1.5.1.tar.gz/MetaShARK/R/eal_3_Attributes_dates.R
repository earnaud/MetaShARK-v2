guessDateTimeFormat <- function(date) {
  compos <- unlist(strsplit(as.character(date), split = "[[:punct:]]"))
  potentialities <- rep(
    list(c("YYYY", "YY", "MM", "DD", "hh", "mm", "ss")),
    length(compos)
  )
  
  # Any is 4-character long: YYYY
  sapply(seq(compos), function(cind) {
    compo <- as.numeric(compos[cind])
    pot <<- potentialities[[cind]]
    if(nchar(compo) == 4)
      pot <<- "YYYY"
    else
      pot <<- pot[pot != "YYYY"]
    
    if(length(pot) > 1){
      if(compo > 60){
        pot <<- pot[pot != "ss"]
        pot <<- pot[pot != "mm"]
      }
      if(compo > 31)
        pot <<- pot[pot != "DD"]
      if(compo > 24)
        pot <<- pot[pot != "hh"]
      if(compo > 12)
        pot <<- pot[pot != "MM"]
    }
    
    potentialities[[cind]] <<- pot
  })
  names(potentialities) <- compos
  
  # Once restricted, let's check the possibilities
  types <- list(year = 0, month = 1, day = 2, hour = 3, minute = 4, second = 5)
  
  
  
  return(potentialities)
}