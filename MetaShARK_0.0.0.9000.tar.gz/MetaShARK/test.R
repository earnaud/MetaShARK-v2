# CRUL ====
library("crul")
library("dplyr")

credentials <- list(
  userId = '0000-0003-3416-7653',
  password = readline("Password? ")
)
orcid_sess <- HttpClient$new(
  url = "https://orcid.org/",
  headers = list(
    Accept = "application/json"
  )
)
auth <- orcid_sess$post(
  "/signin/auth.json",
  body = credentials
)

cookie <- curl::handle_cookies(res$handle) %>%
  filter(name == "XSRF-TOKEN") %>%
  select(value) %>%
  unlist %>%
  unname
orcid_sess$headers$`x-xsrf-token` <- cookie

# continue 

auth <- orcid_sess$post("/signin/auth.json", body = credentials)
auth$parse()

'https://cn.dataone.org/portal/oauth?action=start'
token <- session$get('https://cn.dataone.org/portal/token')
token$status_http()

# HTTR ====
library(httr)

oauth2.0_token(
  endpoint = oauth_endpoint(
    base_url = 'https://orcid.org/',
    authorize = "signin/auth.json"
  ),
  app = oauth_app(
    'orcid',
    
  )
)
