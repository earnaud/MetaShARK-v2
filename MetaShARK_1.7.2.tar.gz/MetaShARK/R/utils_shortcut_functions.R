#' @noRd
seq_row <- function(x) seq(nrow(x))