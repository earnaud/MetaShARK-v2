library(testthat)

test_dir("testthat")

# devtools::document(); devtools::load_all(); shinytest::recordTest("tests/testthat/app/")
