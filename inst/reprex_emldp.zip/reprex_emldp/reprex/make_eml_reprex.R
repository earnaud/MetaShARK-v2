setwd("~/dataPackagesOutput/emlAssemblyLine/2020-02-24_test_fixed_emldp/")

library(EMLassemblyline)

path = "."
data = "./2020-02-24_test/data_objects/"
eml = "./2020-02-24_test/eml/"

# Read templates and data into x

x <- template_arguments(
  path = path,
  data.path = data,
  data.table = dir(data)
)

# Add arguments to x

x$path <- path
x$data.path <- data
x$eml.path <- eml
x$data.table <- c('decomp.csv', 'nitrogen.csv')
x$data.table.name <- c('Decomposition data table', 'Nitrogen data table')
x$data.table.description <- c('Description of the decomposition data table', 'Description of the nitrogen data table')
x$dataset.title <- "Dataset title"
x$maintenance.description <- "Complete"
x$package.id <- "SomepackageID"
x$return.obj <- TRUE
x$temporal.coverage <- c('2014-05-01', '2015-10-31')
x$user.domain <- "UserDomain"
x$user.id <- "UserID"
x$write.file <- TRUE

# Unused arguments must be removed from x

x$geographic.coordinates <- NULL
x$geographic.description <- NULL

# Call make_eml()

output <- do.call(
  make_eml, 
  x[names(x) %in% names(formals(make_eml))])
