#' @noRd
seq_row <- function(x) seq(nrow(x))

#' @noRd
app_sys <- function(...) {
  system.file(..., package = "MetaShARK")
}

