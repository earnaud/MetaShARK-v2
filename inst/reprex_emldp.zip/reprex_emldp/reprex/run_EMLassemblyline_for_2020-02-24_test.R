# This script executes an EMLassemblyline workflow.
