MetaFINUI <- function(id, main.env) {
  ns <- NS(id)
  tagList(
    tags$h1("Nothing yet ...")
  )
}

MetaFIN <- function(id, main.env) {
moduleServer(id, function(input, output, session) {
  
  # Resources
  # * EML schema as list (offer to chose EML version?)
  
  # Select metadata file
  # * turns into list
  # ** save an unedited XML node object
  # Edit
  # * Select a node
  # * Update UI
  # ** edit content
  # ** edit attributes
  # ** remove children
  # ** add children
  # Save / quit
  # * turns back into XML
  
  })
}