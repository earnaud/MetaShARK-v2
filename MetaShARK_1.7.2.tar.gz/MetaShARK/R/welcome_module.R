#' @import shiny
#'
#' @noRd
welcomeUI <- function(id) {
  ns <- NS(id)

  fluidPage(
    mainPanel(
      width = 12,
      tags$h1("Welcome in MetaShARK"),
      tags$div(
        shinyjs::hidden(
          wipRow(
            id = ns("disclaimer_wip"),
            additional_classes = "disclaimer",
            tags$h4("Disclaimer"),
            tags$p("(click to dismiss)"),
            "Some features are still in development. Some parts with this color
          code are not meant to be fully functional."
          )
        ),
        # MetaShARK ====
        fluidRow(
          class = "welcome-row",
          tags$h2("MetaShARK"),
          tags$div(
            class = "welcome-outer",
            tags$div(
              class = "welcome-innerleft",
              tags$img(
                src = "media/logo_pndb.png",
                width = "139px",
                height = "104px"
              )
            ),
            tags$div(
              class = "welcome-innerright",
              tags$p(
                tags$b("MetaShARK"), HTML("(<b>Meta</b>data
                <b>Sh</b>iny <b>A</b>utomated <b>R</b>esources and
                <b>K</b>nowledge) is a tool designed for ecology
                data description tasks. The tool relies on ecology metadata
                standards, and mainly the
                <a href='https://eml.ecoinformatics.org/'>Ecological Metadata
                Language</a>. Its vocation is to allow any ecologist to fill in
                metadata for its dataset to permit the understanding,
                resusability and reproducibility of his work. But as metadata is
                becoming more and more complex, this tool is trying to get as
                <i>user-friendly</i> as possible.")
              ),
              tags$p(
                tags$code("MetaShARK"), " is written and maintained by the French
          National Biodiversity Data Hub (PNDB). You can interact with the
          development team on their ",
                tags$a("git repository.",
                       href = "https://github.com/earnaud/MetaShARK-v2"
                )
              ),
              tags$h3("EML"),
              tags$p(
                "The", tags$b("Ecological Metadata Language"), HTML("has been
            developped since 1997 from the work of <a href='https://www.researchgate.net/publication/220040725_Non-geospatial_metadata_for_the_ecological_sciences'>
            Michener et al.</a>. Since then, it has been developped by the
            <b>NCEAS</b> (National Center for Ecological Analysis and Synthesis)
            and is mainly accessible through its
            <a href='https://github.com/NCEAS/eml'>github repository</a>.
            However, MetaShARK offers a <a href='#shiny-tab-documentation'>
            documentation section</a> dedicated to EML. Since the 2.2.0 release,
            EML published an online documentation, accessible from the
            Documentation tab.")
              ),
              tags$h3("MetaCat & MetaShark"),
              tags$p(
                HTML("The application you are currently using is a front-end
                tool for any user who wants to contribute to a DataOne node
                repository, also known as <b>metadata catalogue</b> or
                <b>MetaCat</b>. To contribute to a MetaCat, you need to login to
                the metacat in which you want to upload your data package. Then,
                it will be possible for MetaShARK to gather the needed
                informations, as you will see while using the app. The upload
                feature is accessible from the Upload tab. It will require to
                have a written EML file available in this instance of
                MetaShARK.")
              )
            )
          )
        ),
        # end MetaShARK
        # EAL ====
        fluidRow(
          class = "welcome-row",
          tags$h2("About EML Assembly Line"),
          tags$div(
            class = "welcome-outer",
            tags$div(
              tags$img(
                src = "media/edi_logo_small.png",
                width = "100px",
                height = "100px"
              ),
              class = "welcome-innerleft"
            ),
            tags$div(
              class = "welcome-innerright",
              tags$h3("Authorship"),
              tags$p(
                "The ", tags$code("EML Assembly Line"), " package used in this app
              and its children is the intellectual property of the Environment
              Data Initiative (EDI). You can find further details on their ",
                tags$a("git repository", href = "https://github.com/EDIorg/EMLassemblyline")
              ),
              tags$h3("Usage"),
              HTML(
                "<p><b>EMLassemblyline</b> is a metadata builder for scientists
                and data managers who need to easily create high quality
                <b>EML</b> metadata for data publication. It emphasizes
                auto-extraction of metadata, appends value added content,
                and accepts user supplied inputs through template files
                thereby minimizing user effort while maximizing the potential
                of future data discovery and reuse. EMLassemblyline requires
                no familiarity with EML, is great for managing 10-100s of
                data packages, accepts all data formats, and supports complex
                and fully reproducible science workflows. Furthermore, it
                incorporates <a href=\"https://environmentaldatainitiative.files.wordpress.com/2017/11/emlbestpractices-v3.pdf\">EML best practices</a>,
                is based on a simple file organization scheme, and is not tied
                to a specific data repository.</p>
                <i>(preface by Colin Smith, EDI)</i>"
              ) # end about
            )
          )
        )
      )
      # (end) -----
    )
  )
}

welcome <- function(id, main_env) {
  moduleServer(id, function(input, output, session) {
    shinyjs::toggle("disclaimer_wip", condition = isTRUE(main_env$dev))

    shinyjs::onclick(session$ns("disclaimer_wip"), {
      shinyjs::hide("disclaimer_wip", anim = TRUE, time = 0.25)
    }, asis = TRUE)

  })
}