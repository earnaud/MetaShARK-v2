library(testthat)

test_dir("tests/testthat/")
